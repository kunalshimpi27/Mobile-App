package com.example.collabrativenotes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.SignInButton;
import android.content.Intent;
import com.google.android.gms.tasks.Task;
import android.util.Log;
import android.net.Uri;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;






public class MainActivity extends AppCompatActivity {
    GoogleSignInClient mGoogleSignInClient;
    Button myButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button myButton = findViewById(R.id.login);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent login=new Intent(MainActivity.this, Login.class);
                startActivity(login);
            }
        });

    }
}